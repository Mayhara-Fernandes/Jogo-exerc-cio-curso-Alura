//código carros y
let yCarros= [40, 95, 150, 265, 320];
let velocidadeCarros = [2, 2.5, 3.2, 1, 2]
let xCarros = [600, 600, 600, -10, -10]
let comprimentoCarro = 50
let alturaCarro= 40


function mostraCarro(){
  for (let i = 0; i <imagemCarros.length; i++){
  image(imagemCarros[i], xCarros[i], yCarros[i], comprimentoCarro, alturaCarro );
  }
}

function movimentaCarro (){
  for (let i=0; i<3; i++){
  xCarros[i] -= velocidadeCarros[i] ;
  }
    for (let i=3; i<5; i++){
  xCarros[i] += velocidadeCarros[i] ;
  
  }
}

function voltaPosicaoInicialdoCarro(){
  for (let i=0; i< 3; i++){
    if (passouDaTelaDireita(xCarros[i])){
      xCarros[i] = 600
    }
  }
    for (let i=3; i<5 ; i++)
    if (passouDaTelaEsquerda(xCarros[i])){
      xCarros[i]  = -50;
    }
}
    
function passouDaTelaDireita (xCarros){
 return xCarros < - 50
}
function passouDaTelaEsquerda (xCarros){
  return xCarros > 600
}